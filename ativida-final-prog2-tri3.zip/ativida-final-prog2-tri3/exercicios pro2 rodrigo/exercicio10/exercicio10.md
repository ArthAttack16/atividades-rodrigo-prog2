A. Histórico do navegador: Pilha

A pilha é adequada porque segue o princípio LIFO, em que o último item adicionado é o primeiro a ser removido. Ao voltar no navegador, a página mais recentemente acessada é a primeira a ser retirada do histórico.

B. Pessoas aguardando atendimento: Fila

A fila é adequada porque segue o princípio FIFO, em que o primeiro a entrar é o primeiro a ser atendido. Isso mantém a ordem de chegada das pessoas.

C. Catálogo de produtos: Lista

A lista é adequada porque permite armazenar vários produtos e acessar, adicionar ou remover itens de forma organizada. Não é necessário seguir uma ordem específica de entrada ou saída.

D. Função “desfazer” de um editor de texto: Pilha

A pilha é adequada porque a última alteração feita deve ser a primeira a ser desfeita. Cada nova alteração é adicionada ao topo e o comando “desfazer” remove a alteração mais recente.

E. Playlist de músicas que pode ser acessada por posição: Lista

A lista é adequada porque permite armazenar as músicas e acessá-las diretamente por sua posição, como primeira, segunda, terceira música etc.