const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function somaRecursiva(numeros) {
    if (numeros.length === 0) {
        return 0;
    }

    return numeros[0] + somaRecursiva(numeros.slice(1));
}

rl.question("Digite os números separados por espaço: ", function(entrada) {

    const numeros = entrada.split(" ").map(Number);

    console.log("Lista:", numeros);
    console.log("Soma:", somaRecursiva(numeros));

    rl.close();
});