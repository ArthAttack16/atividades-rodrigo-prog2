const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function maiorValor(numeros) {
    return Math.max(...numeros);
}

function menorValor(numeros) {
    return Math.min(...numeros);
}

function calcularMedia(numeros) {
    let soma = 0;

    for (let numero of numeros) {
        soma += numero;
    }

    return soma / numeros.length;
}

function quantidadePares(numeros) {
    let quantidade = 0;

    for (let numero of numeros) {
        if (numero % 2 === 0) {
            quantidade++;
        }
    }

    return quantidade;
}

function quantidadeImpares(numeros) {
    let quantidade = 0;

    for (let numero of numeros) {
        if (numero % 2 !== 0) {
            quantidade++;
        }
    }

    return quantidade;
}

rl.question("Digite os números separados por espaço: ", function(entrada) {

    const numeros = entrada.split(" ").map(Number);

    console.log("Números:", numeros);
    console.log("Maior valor:", maiorValor(numeros));
    console.log("Menor valor:", menorValor(numeros));
    console.log("Média:", calcularMedia(numeros).toFixed(1));
    console.log("Quantidade de pares:", quantidadePares(numeros));
    console.log("Quantidade de ímpares:", quantidadeImpares(numeros));

    rl.close();
});
