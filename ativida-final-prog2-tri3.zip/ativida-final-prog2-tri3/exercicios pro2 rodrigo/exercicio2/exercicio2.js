const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function validarNome(nome) {
    return nome.trim() !== "";
}

function validarIdade(idade) {
    return idade >= 14 && idade <= 120;
}

function validarEmail(email) {
    return email.includes("@") && email.includes(".");
}

function validarSenha(senha) {
    return senha.length >= 8;
}

function cadastrar() {
    rl.question("Digite seu nome: ", function(nome) {

        if (!validarNome(nome)) {
            console.log("Nome inválido.");
            return cadastrar();
        }

        rl.question("Digite sua idade: ", function(idade) {
            idade = Number(idade);

            if (!validarIdade(idade)) {
                console.log("Idade inválida.");
                return cadastrar();
            }

            rl.question("Digite seu e-mail: ", function(email) {

                if (!validarEmail(email)) {
                    console.log("E-mail inválido.");
                    return cadastrar();
                }

                rl.question("Digite sua senha: ", function(senha) {

                    if (!validarSenha(senha)) {
                        console.log("A senha deve ter pelo menos 8 caracteres.");
                        return cadastrar();
                    }

                    console.log("Cadastro realizado com sucesso!");
                    console.log("Nome:", nome);
                    console.log("Idade:", idade);
                    console.log("E-mail:", email);

                    rl.close();
                });
            });
        });
    });
}

cadastrar();
