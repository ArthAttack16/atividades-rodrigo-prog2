const readline = require("readline");

const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});

class Pessoa {
constructor(nome, dataNascimento) {
this.nome = nome;
this.dataNascimento = dataNascimento;
}

apresentarDados() {
    console.log("Nome:", this.nome);
    console.log("Data de nascimento:", this.dataNascimento);
}

}

class Aluno extends Pessoa {
constructor(nome, dataNascimento, matricula, curso, notas) {
super(nome, dataNascimento);
this.matricula = matricula;
this.curso = curso;
this.notas = notas;
}

calcularMedia() {
    let soma = 0;

    for (let nota of this.notas) {
        soma += nota;
    }

    return soma / this.notas.length;
}

apresentarDados() {
    super.apresentarDados();
    console.log("Matrícula:", this.matricula);
    console.log("Curso:", this.curso);
    console.log("Notas:", this.notas);
    console.log("Média:", this.calcularMedia());
}

}

class Professor extends Pessoa {
constructor(nome, dataNascimento, matricula, disciplina) {
super(nome, dataNascimento);
this.matricula = matricula;
this.disciplina = disciplina;
}

apresentarDados() {
    super.apresentarDados();
    console.log("Matrícula:", this.matricula);
    console.log("Disciplina:", this.disciplina);
}

}

let aluno = new Aluno(
"Arthur",
"16/09/2008",
"2024313686",
"Informática",
[6, 7, 6]
);

let professor = new Professor(
"Rodrigo",
"011/01/1990",
"P067",
"Programação"
);

function menu() {
console.log("\n1 - Mostrar aluno");
console.log("2 - Mostrar professor");
console.log("0 - Sair");

rl.question("Escolha: ", function(opcao) {

    if (opcao === "1") {
        aluno.apresentarDados();
        menu();

    } else if (opcao === "2") {
        professor.apresentarDados();
        menu();

    } else if (opcao === "0") {
        rl.close();

    } else {
        console.log("Opção inválida.");
        menu();
    }
});

}

menu();
