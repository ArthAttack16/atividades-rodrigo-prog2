const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let historico = [];

function menu() {
    console.log("\n1 - Visitar");
    console.log("2 - Página atual");
    console.log("3 - Voltar");
    console.log("4 - Histórico");
    console.log("0 - Sair");

    rl.question("Escolha: ", function(opcao) {

        if (opcao === "1") {
            rl.question("Página: ", function(pagina) {
                historico.push(pagina);
                menu();
            });

        } else if (opcao === "2") {
            console.log(historico.length > 0
                ? "Página atual: " + historico[historico.length - 1]
                : "Nenhuma página visitada.");
            menu();

        } else if (opcao === "3") {
            if (historico.length > 1) {
                historico.pop();
                console.log("Página atual:", historico[historico.length - 1]);
            } else {
                console.log("Não há página anterior.");
            }
            menu();

        } else if (opcao === "4") {
            console.log("Histórico:", historico);
            menu();

        } else if (opcao === "0") {
            rl.close();

        } else {
            console.log("Opção inválida.");
            menu();
        }
    });
}

menu();

// A pilha é adequada porque segue a lógica LIFO, onde a última página visitada é a primeira a ser retirada. Assim, ao voltar, usamos pop() para remover a página atual e acessar a página visitada anteriormente.