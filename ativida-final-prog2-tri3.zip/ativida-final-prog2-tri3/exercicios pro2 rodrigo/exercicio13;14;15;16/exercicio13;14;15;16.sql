CREATE TABLE autores (
    id INT PRIMARY KEY,
    nome VARCHAR(100)
);

CREATE TABLE livros (
    id INT PRIMARY KEY,
    titulo VARCHAR(150),
    ano INT,
    id_autor INT,
    disponivel BOOLEAN,
    FOREIGN KEY (id_autor) REFERENCES autores(id)
);

CREATE TABLE usuarios (
    id INT PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100)
);

CREATE TABLE emprestimos (
    id INT PRIMARY KEY,
    id_livro INT,
    id_usuario INT,
    data_emprestimo DATE,
    data_devolucao DATE,
    FOREIGN KEY (id_livro) REFERENCES livros(id),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id)
);

INSERT INTO autores (id, nome) VALUES
(1, 'Machado de Assis'),
(2, 'George Orwell'),
(3, 'J. K. Rowling');

INSERT INTO livros (id, titulo, ano, id_autor, disponivel) VALUES
(1, 'Dom Casmurro', 1899, 1, FALSE),
(2, 'Memórias Póstumas de Brás Cubas', 1881, 1, TRUE),
(3, '1984', 1949, 2, TRUE),
(4, 'A Revolução dos Bichos', 1945, 2, TRUE),
(5, 'Harry Potter e a Pedra Filosofal', 1997, 3, FALSE);

INSERT INTO usuarios (id, nome, email) VALUES
(1, 'Arthur', 'arthur@email.com'),
(2, 'João', 'joao@email.com'),
(3, 'Maria', 'maria@email.com');

INSERT INTO emprestimos
(id, id_livro, id_usuario, data_emprestimo, data_devolucao)
VALUES
(1, 1, 1, '2026-09-01', NULL),
(2, 3, 2, '2026-09-02', '2026-09-10'),
(3, 5, 3, '2026-09-05', NULL);

SELECT * FROM livros;

SELECT livros.titulo, autores.nome AS autor
FROM livros
JOIN autores ON livros.id_autor = autores.id;

SELECT livros.titulo
FROM livros
JOIN autores ON livros.id_autor = autores.id
WHERE autores.nome = 'Machado de Assis';

SELECT * FROM livros
ORDER BY titulo;

SELECT * FROM livros
WHERE disponivel = TRUE;

UPDATE usuarios
SET nome = 'Carlos'
WHERE id = 1;

UPDATE livros
SET disponivel = TRUE
WHERE id = 1;

UPDATE emprestimos
SET data_devolucao = '2026-09-15'
WHERE id = 1;

SELECT usuarios.nome, livros.titulo
FROM emprestimos
JOIN usuarios ON emprestimos.id_usuario = usuarios.id
JOIN livros ON emprestimos.id_livro = livros.id;

SELECT usuarios.nome, livros.titulo,
       emprestimos.data_emprestimo,
       emprestimos.data_devolucao
FROM emprestimos
JOIN usuarios ON emprestimos.id_usuario = usuarios.id
JOIN livros ON emprestimos.id_livro = livros.id;

SELECT usuarios.nome, livros.titulo,
       emprestimos.data_emprestimo
FROM emprestimos
JOIN usuarios ON emprestimos.id_usuario = usuarios.id
JOIN livros ON emprestimos.id_livro = livros.id
WHERE emprestimos.data_devolucao IS NULL;

SELECT usuarios.nome, COUNT(emprestimos.id) AS quantidade
FROM usuarios
LEFT JOIN emprestimos
ON usuarios.id = emprestimos.id_usuario
GROUP BY usuarios.id, usuarios.nome;

SELECT livros.titulo
FROM livros
LEFT JOIN emprestimos
ON livros.id = emprestimos.id_livro
WHERE emprestimos.id IS NULL;

DELETE FROM usuarios
WHERE id = 3;

DELETE FROM livros
WHERE id = 4;