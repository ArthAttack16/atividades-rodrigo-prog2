const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let tarefas = [];

function menu() {
    console.log("\n1 - Adicionar");
    console.log("2 - Listar");
    console.log("3 - Buscar");
    console.log("4 - Alterar");
    console.log("5 - Remover");
    console.log("6 - Quantidade");
    console.log("0 - Sair");

    rl.question("Escolha: ", function(opcao) {

        if (opcao === "1") {
            rl.question("Digite a tarefa: ", function(tarefa) {
                tarefas.push(tarefa);
                console.log("Tarefa adicionada!");
                menu();
            });

        } else if (opcao === "2") {
            console.log(tarefas);
            menu();

        } else if (opcao === "3") {
            rl.question("Digite a tarefa: ", function(tarefa) {
                if (tarefas.includes(tarefa)) {
                    console.log("Tarefa encontrada!");
                } else {
                    console.log("Tarefa não encontrada.");
                }
                menu();
            });

        } else if (opcao === "4") {
            rl.question("Digite o número da tarefa: ", function(numero) {
                rl.question("Digite a nova tarefa: ", function(novaTarefa) {
                    tarefas[Number(numero) - 1] = novaTarefa;
                    console.log("Tarefa alterada!");
                    menu();
                });
            });

        } else if (opcao === "5") {
            rl.question("Digite o número da tarefa: ", function(numero) {
                tarefas.splice(Number(numero) - 1, 1);
                console.log("Tarefa removida!");
                menu();
            });

        } else if (opcao === "6") {
            console.log("Quantidade:", tarefas.length);
            menu();

        } else if (opcao === "0") {
            rl.close();

        } else {
            console.log("Opção inválida.");
            menu();
        }
    });
}

menu();