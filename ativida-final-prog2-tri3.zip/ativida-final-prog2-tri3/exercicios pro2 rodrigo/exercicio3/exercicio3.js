const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function soma(a, b) {
    return a + b;
}

function subtracao(a, b) {
    return a - b;
}

function multiplicacao(a, b) {
    return a * b;
}

function divisao(a, b) {
    return a / b;
}

function potencia(a, b) {
    return a ** b;
}

function resto(a, b) {
    return a % b;
}

function calcular() {
    console.log("\n--- CALCULADORA ---");
    console.log("1 - Soma");
    console.log("2 - Subtração");
    console.log("3 - Multiplicação");
    console.log("4 - Divisão");
    console.log("5 - Potência");
    console.log("6 - Resto da divisão");
    console.log("0 - Sair");

    rl.question("Escolha uma opção: ", function(opcao) {

        if (opcao === "0") {
            console.log("Calculadora encerrada.");
            rl.close();
            return;
        }

        if (opcao < "1" || opcao > "6") {
            console.log("Opção inválida.");
            return calcular();
        }

        rl.question("Digite o primeiro número: ", function(valor1) {
            rl.question("Digite o segundo número: ", function(valor2) {

                let a = Number(valor1);
                let b = Number(valor2);
                let resultado;

                if ((opcao === "4" || opcao === "6") && b === 0) {
                    console.log("Não é possível dividir por zero.");
                    return calcular();
                }

                if (opcao === "1") {
                    resultado = soma(a, b);
                } else if (opcao === "2") {
                    resultado = subtracao(a, b);
                } else if (opcao === "3") {
                    resultado = multiplicacao(a, b);
                } else if (opcao === "4") {
                    resultado = divisao(a, b);
                } else if (opcao === "5") {
                    resultado = potencia(a, b);
                } else if (opcao === "6") {
                    resultado = resto(a, b);
                }

                console.log("Resultado:", resultado);

                calcular();
            });
        });
    });
}

calcular();
