const express = require("express");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const db = new sqlite3.Database("./banco.sqlite");

app.use(express.json());
app.use(express.static(__dirname + "/public"));

class Tarefa {
    constructor(id, descricao, concluida) {
        this.id = id;
        this.descricao = descricao;
        this.concluida = concluida;
    }
}

db.run(`
    CREATE TABLE IF NOT EXISTS tarefas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        descricao TEXT NOT NULL,
        concluida INTEGER DEFAULT 0
    )
`);

app.get("/tarefas", (req, res) => {
    db.all("SELECT * FROM tarefas", [], (erro, tarefas) => {
        if (erro) {
            res.status(500).json({ erro: "Erro ao buscar tarefas" });
            return;
        }

        let lista = [];

        for (let tarefa of tarefas) {
            lista.push(
                new Tarefa(tarefa.id, tarefa.descricao, tarefa.concluida)
            );
        }

        res.json(lista);
    });
});

app.post("/tarefas", (req, res) => {
    const descricao = req.body.descricao;

    if (!descricao || descricao.trim() === "") {
        res.status(400).json({ erro: "A descrição é obrigatória" });
        return;
    }

    db.run(
        "INSERT INTO tarefas (descricao) VALUES (?)",
        [descricao],
        function(erro) {
            if (erro) {
                res.status(500).json({ erro: "Erro ao criar tarefa" });
                return;
            }

            res.json({
                id: this.lastID,
                descricao: descricao,
                concluida: 0
            });
        }
    );
});

app.put("/tarefas/:id", (req, res) => {
    const id = req.params.id;
    const descricao = req.body.descricao;
    const concluida = req.body.concluida;

    if (!descricao || descricao.trim() === "") {
        res.status(400).json({ erro: "A descrição é obrigatória" });
        return;
    }

    db.run(
        "UPDATE tarefas SET descricao = ?, concluida = ? WHERE id = ?",
        [descricao, concluida, id],
        function(erro) {
            if (erro) {
                res.status(500).json({ erro: "Erro ao atualizar tarefa" });
                return;
            }

            res.json({ mensagem: "Tarefa atualizada" });
        }
    );
});

app.delete("/tarefas/:id", (req, res) => {
    const id = req.params.id;

    db.run(
        "DELETE FROM tarefas WHERE id = ?",
        [id],
        function(erro) {
            if (erro) {
                res.status(500).json({ erro: "Erro ao excluir tarefa" });
                return;
            }

            res.json({ mensagem: "Tarefa excluída" });
        }
    );
});

app.listen(3000, () => {
    console.log("Servidor rodando em http://localhost:3000");
});