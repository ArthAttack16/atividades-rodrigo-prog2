let tarefas = [];

async function listarTarefas() {
    const resposta = await fetch("/tarefas");
    tarefas = await resposta.json();

    const lista = document.getElementById("lista");
    lista.innerHTML = "";

    for (let tarefa of tarefas) {
        const item = document.createElement("li");

        if (tarefa.concluida === 1) {
            item.style.textDecoration = "line-through";
        }

        item.innerHTML = `
            ${tarefa.descricao}
            <button onclick="concluirTarefa(${tarefa.id})">Concluir</button>
            <button onclick="excluirTarefa(${tarefa.id})">Excluir</button>
        `;

        lista.appendChild(item);
    }
}

async function adicionarTarefa(event) {
    event.preventDefault();

    const descricao = document.getElementById("descricao").value;

    if (descricao.trim() === "") {
        return;
    }

    await fetch("/tarefas", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            descricao: descricao
        })
    });

    document.getElementById("descricao").value = "";

    listarTarefas();
}

async function concluirTarefa(id) {
    const tarefa = tarefas.find(t => t.id === id);

    await fetch("/tarefas/" + id, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            descricao: tarefa.descricao,
            concluida: 1
        })
    });

    listarTarefas();
}

async function excluirTarefa(id) {
    await fetch("/tarefas/" + id, {
        method: "DELETE"
    });

    listarTarefas();
}

listarTarefas();
