const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function fatorial(numero) {
    if (numero === 0 || numero === 1) {
        return 1;
    }

    return numero * fatorial(numero - 1);
}

rl.question("Digite um número inteiro não negativo: ", function(entrada) {

    const numero = Number(entrada);

    if (numero < 0 || !Number.isInteger(numero)) {
        console.log("Digite um número inteiro não negativo.");
    } else {
        console.log("Fatorial:", fatorial(numero));
    }

    rl.close();
});

// PERGUNTAS

// 1. Qual é o caso-base da função? O caso-base é:

// if (numero === 0 || numero === 1) {
// return 1;
// }

// 2. O que aconteceria se o caso-base não existisse? A função continuaria chamando ela mesma infinitamente, até o programa gerar um erro por excesso de chamadas na memória.

// 3. Qual seria uma versão não recursiva do mesmo algoritmo? Seria: 

// function fatorial(numero) { 
// let resultado = 1; 
// for (let i = 1; i <= numero; i++) { 
// resultado = resultado * i; 
// } 
// return resultado; 
// }