const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function fibonacciRecursivo(n) {
    if (n === 0 || n === 1) {
        return n;
    }

    return fibonacciRecursivo(n - 1) + fibonacciRecursivo(n - 2);
}

function fibonacciRepeticao(n) {
    let anterior = 0;
    let atual = 1;

    for (let i = 0; i < n; i++) {
        let proximo = anterior + atual;
        anterior = atual;
        atual = proximo;
    }

    return anterior;
}

rl.question("Digite a posição de Fibonacci: ", function(entrada) {

    const n = Number(entrada);

    if (n < 0 || !Number.isInteger(n)) {
        console.log("Digite um número inteiro não negativo.");
    } else {
        console.log("Recursivo:", fibonacciRecursivo(n));
        console.log("Com repetição:", fibonacciRepeticao(n));
    }

    rl.close();
});

// A versão com repetição é mais eficiente para valores altos, pois a versão recursiva repete vários cálculos desnecessariamente, enquanto a versão com repetição calcula cada termo apenas uma vez.