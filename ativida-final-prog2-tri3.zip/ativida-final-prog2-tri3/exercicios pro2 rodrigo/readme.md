# Questão 20: Sistema de Tarefas 

## 1. Sobre o projeto

Este projeto consiste em um sistema web de gerenciamento de tarefas.

O sistema permite que o usuário cadastre novas tarefas, visualize as tarefas existentes, marque tarefas como concluídas e exclua tarefas.

## 2. Tecnologias utilizadas

- HTML
- CSS
- JavaScript
- NodeJs
- Express
- SQLite

## 3. Arquitetura cliente-servidor

A aplicação utiliza uma arquitetura cliente-servidor, na qual o cliente é responsável pela interface e pela interação com o usuário, enquanto o servidor processa as requisições e realiza as operações no banco de dados.

Explicação passo a passo:

1. O usuário interage com a interface HTML.

2. O JavaScript do cliente envia uma requisição HTTP utilizando fetch().

3. O servidor recebe a requisição através do Express.

4. O servidor processa os dados e executa as operações necessárias no banco SQLite.

5. O servidor devolve uma resposta ao cliente.

6. O JavaScript atualiza a lista de tarefas exibida na página.

## 4. Rotas e requisições HTTP

O servidor possui quatro rotas principais:

### GET /tarefas

Responsável por consultar todas as tarefas cadastradas no banco de dados.

### POST /tarefas

Responsável por cadastrar uma nova tarefa.

### PUT /tarefas/:id

Responsável por atualizar uma tarefa existente. No sistema atual, essa rota é utilizada para marcar uma tarefa como concluída.

### DELETE /tarefas/:id

Responsável por excluir uma tarefa.

## 5. Operações CRUD

O sistema implementa as quatro operações básicas de manipulação de dados:

- CREATE: cadastro de uma nova tarefa através do formulário.

- READ: visualização das tarefas cadastradas.

- UPDATE: alteração do estado de uma tarefa para concluída.

- DELETE: exclusão de uma tarefa

## 6. Orientação a objetos: classe Tarefa

Foi criada a classe Tarefa, localizada no arquivo servidor.js. Essa classe representa uma tarefa do sistema e possui três atributos:

- id: identificador da tarefa.

- descricao: texto que descreve a tarefa.

- concluida: indica se a tarefa foi concluída.

O construtor recebe esses três valores e os associa ao objeto através de this. A classe é utilizada na consulta das tarefas, permitindo transformar os registros retornados pelo banco de dados em objetos da classe Tarefa.

## 7. Estrutura de dados

Foi utilizada a estrutura de dados lista, implementada através de arrays do JavaScript.

- No cliente, o array tarefas armazena temporariamente as tarefas recebidas do servidor. Ele também permite localizar uma tarefa pelo seu identificador através do método find().

- No servidor, a rota GET utiliza outro array, chamado lista, para armazenar os objetos Tarefa antes de enviá-los ao cliente.

Essa estrutura permite organizar e percorrer os registros de maneira simples.

## 8. Como executar o projeto

É necessário ter o Node.js instalado.

No terminal, dentro da pasta principal do projeto, execute:

```
nnpm init -y
npm install express sqlite3
```

Depois, inicie o servidor:

```
node servidor.js
```

Com o servidor em execução, acesse pelo navegador:

http://localhost:3000/exercicio20.html

O banco de dados será criado automaticamente, caso ainda não exista.

## 9. Demonstração

Para demonstrar o funcionamento do sistema:

1. Cadastre uma tarefa utilizando o formulário.

2. Verifique se ela aparece na lista.

3. Clique em "Concluir" para alterar seu estado.

4. Verifique se a tarefa aparece com o texto riscado.

5. Clique em "Excluir" para remover a tarefa.

Essas etapas demonstram o funcionamento das operações CRUD e a comunicação entre cliente, servidor e banco de dados.

# Observações e revisão conceitual

As questões com perguntas a serem respondidas contém suas respostas em seus respectivos códigos, como o exercício 19, por exemplo.

## Revisão conceitual

Como solicitado, passarei brevemente pelos conceitos solicitados em "Questões para revisão conceitual".

### Diferença entre função e procedimento:

Uma função executa uma tarefa e retorna um valor. Um procedimento executa uma sequência de instruções, mas não possui necessariamente um valor de retorno.

### Parâmetros e valores de retorno:

Parâmetros são informações recebidas por uma função para realizar determinada tarefa. O valor de retorno é o resultado que ela devolve após sua execução.

### Caso-base em uma função recursiva:

É a condição que encerra as chamadas de uma função recursiva, impedindo que ela continue executando indefinidamente.

### Diferença entre recursão e repetição:

Recursão acontece quando uma função chama a si mesma. Repetição acontece quando um bloco de código é executado várias vezes utilizando estruturas como for e while.

### Funcionamento de listas, pilhas e filas:

- Lista: armazena vários elementos organizados em uma sequência.

- Pilha: permite inserir e remover elementos seguindo uma ordem específica, em que o último inserido é o primeiro removido.

- Fila: permite inserir e remover elementos seguindo a ordem de chegada.

### Conceitos de LIFO e FIFO:

- LIFO (Last In, First Out): último a entrar, primeiro a sair. Utilizado em pilhas.

-  FIFO (First In, First Out): primeiro a entrar, primeiro a sair. Utilizado em filas.

### Classes, objetos, atributos e métodos:

- Classe: modelo utilizado para criar objetos.

- Objeto: instância de uma classe.

- Atributos: características ou informações de um objeto.

- Métodos: funções que pertencem a uma classe ou objeto.

### Encapsulamento e herança:

- Encapsulamento: consiste em proteger e controlar o acesso aos dados e funcionalidades de uma classe.

- Herança: permite que uma classe herde atributos e métodos de outra classe.

### Banco de dados relacional:

É um banco de dados que organiza informações em tabelas, permitindo estabelecer relações entre elas através de campos em comum.

### Chave primária e chave estrangeira:

- Chave primária: identifica exclusivamente cada registro de uma tabela.

- Chave estrangeira: estabelece uma ligação entre tabelas, referenciando a chave primária de outra tabela.

### Comandos CREATE, INSERT, SELECT, UPDATE e DELETE:

- CREATE: cria tabelas ou outras estruturas no banco de dados.

- INSERT: adiciona novos registros.

- SELECT: consulta registros.

- UPDATE: altera registros existentes.

- DELETE: exclui registros.

### Relacionamento entre tabelas e JOIN:

O relacionamento entre tabelas permite conectar informações através de campos relacionados. O JOIN é um comando SQL utilizado para combinar registros de diferentes tabelas.

### Diferença entre cliente e servidor:

O cliente é responsável pela interface e pela interação com o usuário. O servidor recebe as requisições, processa os dados e realiza operações no banco de dados.

### Funcionamento básico do protocolo HTTP:

HTTP é um protocolo de comunicação utilizado para trocar informações entre cliente e servidor. O cliente envia uma requisição e o servidor processa e devolve uma resposta

### Métodos GET, POST, PUT/PATCH e DELETE:

- GET: utilizado para consultar informações.

- POST: utilizado para enviar informações e criar registros.

- PUT: utilizado para atualizar um registro.

- PATCH: utilizado para atualizar parcialmente um registro.

- DELETE: utilizado para excluir registros.

### Códigos de status HTTP:

São códigos que indicam o resultado de uma requisição. Alguns exemplos:

- 200: requisição realizada com sucesso.

- 201: recurso criado com sucesso.

- 400: requisição inválida.

- 404: recurso não encontrado.

- 500: erro interno do servidor.

### HTML semântico:

Consiste em utilizar elementos HTML de acordo com sua finalidade, facilitando a organização, acessibilidade e compreensão do conteúdo da página. Exemplos: header, main, section e footer.

### Seletores CSS:

São utilizados para selecionar elementos HTML e aplicar estilos. Podem selecionar elementos pelo nome da tag, classe ou identificador (ID).

### Flexbox e/ou Grid:

São ferramentas do CSS utilizadas para organizar elementos na página. Flexbox trabalha principalmente com a distribuição de elementos em uma dimensão, enquanto Grid permite organizar layouts em linhas e colunas.

### Funcionamento geral de uma aplicação web integrada a banco de dados:

O cliente envia informações ao servidor através de requisições HTTP. O servidor processa essas informações, realiza operações no banco de dados e devolve uma resposta ao cliente, que atualiza a interface.