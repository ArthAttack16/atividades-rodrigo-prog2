const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Digite o CEP: ", async function(cep) {

    try {
        const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);

        if (!resposta.ok) {
            console.log("Erro na requisição. Código:", resposta.status);
            rl.close();
            return;
        }

        const dados = await resposta.json();

        if (dados.erro) {
            console.log("CEP não encontrado.");
        } else {
            console.log("CEP:", dados.cep);
            console.log("Rua:", dados.logradouro);
            console.log("Bairro:", dados.bairro);
            console.log("Cidade:", dados.localidade);
            console.log("Estado:", dados.uf);
        }

    } catch (erro) {
        console.log("Erro ao fazer a requisição.");
    }

    rl.close();
});

// PERGUNTAS

// 1. Qual URL foi utilizada? https://viacep.com.br/ws/{CEP}/json/

// 2. Qual método HTTP foi utilizado? GET.

// 3. Qual código HTTP representa uma requisição bem-sucedida? 200. 

// 4. Em qual formato os dados foram recebidos? JSON.

// 5. Qual é a diferença entre uma requisição e uma resposta HTTP? A requisição é o pedido enviado pelo cliente para o servidor. A resposta é o que o servidor devolve depois de processar esse pedido.
