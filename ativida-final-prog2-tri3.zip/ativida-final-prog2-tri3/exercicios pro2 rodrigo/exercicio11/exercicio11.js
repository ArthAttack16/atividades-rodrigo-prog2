const readline = require("readline");

const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});

class Produto {
constructor(codigo, nome, preco, quantidade) {
this.codigo = codigo;
this.nome = nome;
this.preco = preco;
this.quantidade = quantidade;
}

adicionar(quantidade) {
    this.quantidade += quantidade;
}

retirar(quantidade) {
    if (quantidade <= this.quantidade) {
        this.quantidade -= quantidade;
    } else {
        console.log("Quantidade insuficiente em estoque.");
    }
}

alterarPreco(novoPreco) {
    this.preco = novoPreco;
}

valorTotal() {
    return this.preco * this.quantidade;
}

}

let produto1 = new Produto(1, "Mouse", 80, 10);
let produto2 = new Produto(2, "Teclado", 150, 5);
let produto3 = new Produto(3, "Monitor", 900, 3);

let produtos = [produto1, produto2, produto3];

function menu() {
console.log("\n1 - Mostrar produtos");
console.log("2 - Adicionar estoque");
console.log("3 - Retirar estoque");
console.log("4 - Alterar preço");
console.log("5 - Ver valor total");
console.log("0 - Sair");

rl.question("Escolha: ", function(opcao) {

    if (opcao === "1") {
        console.log(produtos);
        menu();

    } else if (opcao === "2") {
        rl.question("Código do produto: ", function(codigo) {
            rl.question("Quantidade: ", function(quantidade) {
                produtos[Number(codigo) - 1].adicionar(Number(quantidade));
                console.log("Estoque atualizado.");
                menu();
            });
        });

    } else if (opcao === "3") {
        rl.question("Código do produto: ", function(codigo) {
            rl.question("Quantidade: ", function(quantidade) {
                produtos[Number(codigo) - 1].retirar(Number(quantidade));
                console.log("Estoque atualizado.");
                menu();
            });
        });

    } else if (opcao === "4") {
        rl.question("Código do produto: ", function(codigo) {
            rl.question("Novo preço: ", function(preco) {
                produtos[Number(codigo) - 1].alterarPreco(Number(preco));
                console.log("Preço alterado.");
                menu();
            });
        });

    } else if (opcao === "5") {
        rl.question("Código do produto: ", function(codigo) {
            console.log("Valor total:", produtos[Number(codigo) - 1].valorTotal());
            menu();
        });

    } else if (opcao === "0") {
        rl.close();

    } else {
        console.log("Opção inválida.");
        menu();
    }
});

}

menu();
