const readline = require("readline");

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let fila = [];
let senha = 1;

function menu() {
    console.log("\n1 - Adicionar pessoa");
    console.log("2 - Chamar próxima");
    console.log("3 - Próxima pessoa");
    console.log("4 - Mostrar fila");
    console.log("5 - Quantidade");
    console.log("0 - Sair");

    rl.question("Escolha: ", function(opcao) {

        if (opcao === "1") {
            rl.question("Nome: ", function(nome) {

                let pessoa = {
                    senha: senha,
                    nome: nome,
                    horario: new Date().toLocaleTimeString()
                };

                fila.push(pessoa);
                console.log("Senha:", senha);
                senha++;
                menu();
            });

        } else if (opcao === "2") {
            if (fila.length > 0) {
                let pessoa = fila.shift();
                console.log("Atendendo:", pessoa.nome, "- Senha:", pessoa.senha);
            } else {
                console.log("Fila vazia.");
            }
            menu();

        } else if (opcao === "3") {
            if (fila.length > 0) {
                console.log("Próximo:", fila[0].nome, "- Senha:", fila[0].senha);
            } else {
                console.log("Fila vazia.");
            }
            menu();

        } else if (opcao === "4") {
            console.log(fila);
            menu();

        } else if (opcao === "5") {
            console.log("Pessoas aguardando:", fila.length);
            menu();

        } else if (opcao === "0") {
            rl.close();

        } else {
            console.log("Opção inválida.");
            menu();
        }
    });
}

menu();

// A fila é mais adequada porque segue a ordem de chegada: a primeira pessoa a entrar é a primeira a ser atendida. Isso segue o princípio FIFO (First In, First Out).